@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.advancements.critereon;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;