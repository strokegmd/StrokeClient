@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.advancements;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;