@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.block;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;