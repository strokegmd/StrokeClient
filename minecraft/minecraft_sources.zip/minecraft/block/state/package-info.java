@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.block.state;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;