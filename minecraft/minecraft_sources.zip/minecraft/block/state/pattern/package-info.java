@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.block.state.pattern;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;