@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.block.properties;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;