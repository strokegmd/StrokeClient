package net.minecraft.client.gui.recipebook;

public interface IRecipeShownListener
{
    void func_192043_J_();

    GuiRecipeBook func_194310_f();
}
