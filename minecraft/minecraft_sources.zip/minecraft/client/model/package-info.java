@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.model;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;