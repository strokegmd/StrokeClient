@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.entity;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;