@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.main;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;